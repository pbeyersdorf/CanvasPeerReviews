from canvasapi import Canvas
from datetime import datetime, timedelta
import random
from cpr.review import Review
from cpr.student import Student
from cpr.assignment import GradedAssignment
from cpr.creation import Creation
from cpr.comparison import Comparison
from cpr.parameters import Parameters
from cpr.utilities import *
from cpr.docs import *