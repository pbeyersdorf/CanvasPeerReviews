# CanvasPeerReviews
Python package for managing calibrated peer reviews on canvas.

To install required modules pip install -r requirements.txt
Installation python -m pip install -e path/to/CanvasPeerReviews

To use:

from cpr import *

cprhelp()
